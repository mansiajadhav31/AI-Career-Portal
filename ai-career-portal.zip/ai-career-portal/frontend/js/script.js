// ============ API Configuration ============
const API_BASE = 'http://localhost:5000/api';

// ============ Auth Functions ============
function isLoggedIn() {
    const token = localStorage.getItem('token');
    return token !== null && token !== undefined && token !== '';
}

function getAuthHeader() {
    const token = localStorage.getItem('token');
    return token ? { 'Authorization': `Bearer ${token}` } : {};
}

function showAlert(message, type) {
    const alertDiv = document.getElementById('alert');
    if (alertDiv) {
        alertDiv.textContent = message;
        alertDiv.className = `alert ${type}`;
        alertDiv.style.display = 'block';
        setTimeout(() => alertDiv.style.display = 'none', 3000);
    } else {
        console.log(message);
    }
}

// ============ Login/Register ============
document.getElementById('loginForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    
    try {
        const response = await fetch(`${API_BASE}/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            localStorage.setItem('token', data.token);
            localStorage.setItem('user', JSON.stringify(data.user));
            showAlert('Login successful! Redirecting...', 'success');
            setTimeout(() => window.location.href = 'dashboard.html', 1000);
        } else {
            showAlert(data.error || 'Login failed', 'error');
        }
    } catch (error) {
        showAlert('Network error: ' + error.message, 'error');
    }
});

document.getElementById('registerForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirm = document.getElementById('confirm_password')?.value;
    
    if (password !== confirm) {
        showAlert('Passwords do not match!', 'error');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, email, password })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showAlert('Registration successful! Please login.', 'success');
            setTimeout(() => window.location.href = 'login.html', 1500);
        } else {
            showAlert(data.error || 'Registration failed', 'error');
        }
    } catch (error) {
        showAlert('Network error: ' + error.message, 'error');
    }
});

document.getElementById('logoutBtn')?.addEventListener('click', (e) => {
    e.preventDefault();
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = 'login.html';
});

// ============ Dashboard Functions ============
async function loadDashboard() {
    console.log('Loading dashboard...');
    
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    const userNameSpan = document.getElementById('userName');
    if (userNameSpan) userNameSpan.innerText = user.name || 'User';
    
    await loadDashboardStats();
    await loadRecentResumes();
    loadRecommendations();
    loadCodingChallenges();
}

async function loadDashboardStats() {
    const token = localStorage.getItem('token');
    
    // ============ GET RESUME SCORE FROM LOCALSTORAGE ============
    let resumeScore = localStorage.getItem('latestResumeScore') || 0;
    console.log("Resume score from localStorage:", resumeScore);
    
    // ============ GET CODING DATA FROM LOCALSTORAGE ============
    const submissions = JSON.parse(localStorage.getItem('codingSubmissions') || '[]');
    console.log("Dashboard - Coding submissions:", submissions.length);
    
    // Calculate coding statistics
    const codingScores = submissions.map(s => s.score);
    const totalCodingChallenges = submissions.length;
    const avgCodingScore = codingScores.length > 0 
        ? Math.round(codingScores.reduce((a, b) => a + b, 0) / codingScores.length)
        : 0;
    
    // Update dashboard stats
    const codingCountSpan = document.getElementById('codingCount');
    const resumeScoreSpan = document.getElementById('resumeScore');
    const avgScoreSpan = document.getElementById('avgScore');
    
    if (codingCountSpan) codingCountSpan.innerText = totalCodingChallenges;
    if (resumeScoreSpan) resumeScoreSpan.innerText = resumeScore;
    
    // Calculate overall average
    let overallAvg = avgCodingScore;
    if (resumeScore > 0 && avgCodingScore > 0) {
        overallAvg = Math.round((parseInt(resumeScore) + avgCodingScore) / 2);
    } else if (resumeScore > 0) {
        overallAvg = parseInt(resumeScore);
    } else if (avgCodingScore > 0) {
        overallAvg = avgCodingScore;
    }
    if (avgScoreSpan) avgScoreSpan.innerText = overallAvg;
    
    // Update progress chart with coding data
    if (typeof updateProgressChart === 'function') {
        updateProgressChart({
            resume_score: parseInt(resumeScore),
            avg_score: overallAvg,
            total_coding_challenges: totalCodingChallenges,
            coding_scores: codingScores
        });
    }
    
    // ============ ALSO FETCH FROM BACKEND ============
    if (!token) return;
    
    try {
        const response = await fetch(`${API_BASE}/dashboard/stats`, {
            method: 'GET',
            headers: { 'Authorization': `Bearer ${token}` }
        });
        
        if (response.ok) {
            const data = await response.json();
            console.log("Backend stats:", data);
            
            // Update resume score from backend if available
            if (data.resume_score > 0) {
                const backendResumeScore = data.resume_score;
                localStorage.setItem('latestResumeScore', backendResumeScore);
                if (resumeScoreSpan) resumeScoreSpan.innerText = backendResumeScore;
                resumeScore = backendResumeScore;
            }
            
            // Use max of backend and local data for coding
            const backendCodingCount = data.total_coding_challenges || 0;
            const finalCodingCount = Math.max(totalCodingChallenges, backendCodingCount);
            if (codingCountSpan) codingCountSpan.innerText = finalCodingCount;
            
            // Recalculate overall average with backend data
            const finalResumeScore = data.resume_score || resumeScore;
            const finalAvgScore = Math.max(overallAvg, data.avg_score || 0);
            if (avgScoreSpan) avgScoreSpan.innerText = finalAvgScore;
            
            // Update progress chart again with merged data
            if (typeof updateProgressChart === 'function') {
                updateProgressChart({
                    resume_score: finalResumeScore,
                    avg_score: finalAvgScore,
                    total_coding_challenges: finalCodingCount,
                    coding_scores: [...codingScores, ...(data.coding_scores || [])]
                });
            }
        }
    } catch (error) {
        console.error("Error fetching backend stats:", error);
    }
}
function setDefaultStats() {
    document.getElementById('resumeScore').innerText = '0';
    document.getElementById('interviewCount').innerText = '0';
    document.getElementById('codingCount').innerText = '0';
    document.getElementById('avgScore').innerText = '0';
}

async function loadRecentResumes() {
    const container = document.getElementById('recentResumes');
    if (!container) return;
    
    const token = localStorage.getItem('token');
    console.log('Token for resumes:', token ? 'Present' : 'Missing');
    
    if (!token) {
        container.innerHTML = '<p>Please login to view resumes.</p>';
        return;
    }
    
    container.innerHTML = '<p>Loading resumes...</p>';
    
    try {
        const response = await fetch(`${API_BASE}/user/resumes`, {
            method: 'GET',
            headers: { 'Authorization': `Bearer ${token}` }
        });
        
        console.log('Resumes response status:', response.status);
        
        if (response.status === 401) {
            container.innerHTML = '<p>Session expired. Please login again.</p>';
            localStorage.removeItem('token');
            setTimeout(() => window.location.href = 'login.html', 2000);
            return;
        }
        
        if (response.ok) {
            const data = await response.json();
            console.log('Resumes data:', data);
            
            if (data.resumes && data.resumes.length > 0) {
                container.innerHTML = data.resumes.map(r => `
                    <div style="border-bottom: 1px solid #e0e0e0; padding: 12px;">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <div>
                                <span style="font-size: 18px;">📄</span>
                                <strong>${r.file_path || 'Resume'}</strong>
                            </div>
                            <div>
                                <span style="color: #6366f1; font-weight: bold;">${r.match_score || 0}%</span>
                                <span style="color: #888; font-size: 12px; margin-left: 10px;">${r.uploaded_at?.split('T')[0] || 'Recent'}</span>
                            </div>
                        </div>
                    </div>
                `).join('');
            } else {
                container.innerHTML = '<p>No resumes uploaded yet. Click "Upload Resume" to get started!</p>';
            }
        } else {
            container.innerHTML = `<p>Error: ${response.status} - Unable to load resumes</p>`;
        }
    } catch (error) {
        console.error('Error loading resumes:', error);
        container.innerHTML = '<p>Unable to connect to server. Make sure backend is running.</p>';
    }
}

function loadRecommendations() {
    const container = document.getElementById('recommendations');
    if (!container) return;
    
    container.innerHTML = `
        <p>💡 <strong>AI Tip:</strong> Upload your resume to get personalized job recommendations!</p>
        <p>🎯 Try our Mock Interview and Coding Challenges to boost your skills!</p>
    `;
}

function loadCodingChallenges() {
    const container = document.getElementById('codingChallenges');
    if (!container) {
        console.log("codingChallenges container not found");
        return;
    }
    
    // Get submissions from localStorage
    const submissions = JSON.parse(localStorage.getItem('codingSubmissions') || '[]');
    console.log("Coding submissions found:", submissions.length);
    
    if (submissions.length === 0) {
        container.innerHTML = `
            <p style="color: #666;">No coding challenges attempted yet.</p>
            <a href="coding.html" class="btn btn-primary" style="margin-top: 1rem; display: inline-block;">Start Coding →</a>
        `;
        return;
    }
    
    // Group by question and get latest score for each
    const latestSubmissions = {};
    submissions.forEach(s => {
        if (!latestSubmissions[s.questionId] || new Date(s.date) > new Date(latestSubmissions[s.questionId].date)) {
            latestSubmissions[s.questionId] = s;
        }
    });
    
    const questionNames = {
        1: 'Two Sum',
        2: 'Reverse String',
        3: 'Fizz Buzz',
        4: 'Valid Parentheses',
        5: 'Maximum Subarray',
        6: 'Merge Intervals',
        7: 'LRU Cache',
        8: 'Trapping Rain Water'
    };
    
    // Calculate average score
    const scores = Object.values(latestSubmissions).map(s => s.score);
    const avgScore = scores.length > 0 
        ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length)
        : 0;
    
    container.innerHTML = `
        <div style="margin-bottom: 1rem;">
            <div style="background: #f8f9ff; padding: 12px; border-radius: 8px; margin-bottom: 15px;">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <span><strong>📊 Average Coding Score</strong></span>
                    <span style="font-size: 24px; font-weight: bold; color: #6366f1;">${avgScore}%</span>
                </div>
                <progress value="${avgScore}" max="100" style="width: 100%; height: 8px; border-radius: 4px; margin-top: 8px;"></progress>
            </div>
            <div style="max-height: 250px; overflow-y: auto;">
                ${Object.values(latestSubmissions).map(s => `
                    <div style="display: flex; justify-content: space-between; align-items: center; padding: 10px; border-bottom: 1px solid #e0e0e0;">
                        <div>
                            <strong>${questionNames[s.questionId] || 'Question ' + s.questionId}</strong>
                            <span style="margin-left: 8px; font-size: 11px; color: #666;">${s.language || 'python'}</span>
                        </div>
                        <div>
                            <span style="background: ${s.score >= 70 ? '#d1fae5' : '#fed7aa'}; color: ${s.score >= 70 ? '#166534' : '#9a3412'}; padding: 4px 8px; border-radius: 20px; font-weight: bold; font-size: 12px;">
                                ${s.score}%
                            </span>
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>
        <a href="coding.html" class="btn btn-secondary" style="margin-top: 1rem; display: inline-block;">View All Challenges →</a>
    `;
    
    // Also update coding count in stats
    const codingCountSpan = document.getElementById('codingCount');
    if (codingCountSpan) {
        codingCountSpan.innerText = Object.keys(latestSubmissions).length;
    }
    
    // Update average score in stats
    const resumeScore = parseInt(document.getElementById('resumeScore')?.innerText || 0);
    const avgScoreSpan = document.getElementById('avgScore');
    if (avgScoreSpan) {
        const totalAvg = scores.length > 0 
            ? Math.round((resumeScore + avgScore) / 2)
            : resumeScore;
        avgScoreSpan.innerText = totalAvg;
    }
    
    // Update progress chart
    if (typeof updateProgressChart === 'function') {
        updateProgressChart({
            resume_score: resumeScore,
            avg_score: avgScore,
            total_coding_challenges: Object.keys(latestSubmissions).length,
            coding_scores: scores
        });
    }
}
// Call this function after submitting code to update dashboard
function updateDashboardFromStorage() {
    // Update coding challenges count
    const totalCoding = localStorage.getItem('totalCodingChallenges') || 0;
    const codingCountSpan = document.getElementById('codingCount');
    if (codingCountSpan) codingCountSpan.innerText = totalCoding;
    
    // Update average score
    const avgCodingScore = localStorage.getItem('avgCodingScore') || 0;
    const resumeScore = document.getElementById('resumeScore')?.innerText || 0;
    const avgScore = Math.round((parseInt(resumeScore) + parseInt(avgCodingScore)) / 2);
    const avgScoreSpan = document.getElementById('avgScore');
    if (avgScoreSpan) avgScoreSpan.innerText = avgScore || avgCodingScore;
    
    // Update coding challenges list
    const submissions = JSON.parse(localStorage.getItem('codingSubmissions') || '[]');
    const container = document.getElementById('codingChallenges');
    
    if (container && submissions.length > 0) {
        // Get unique questions with latest scores
        const latestSubmissions = {};
        submissions.forEach(s => {
            if (!latestSubmissions[s.questionId] || new Date(s.date) > new Date(latestSubmissions[s.questionId].date)) {
                latestSubmissions[s.questionId] = s;
            }
        });
        
        const questionNames = {
            1: 'Two Sum', 2: 'Reverse String', 3: 'Fizz Buzz',
            4: 'Valid Parentheses', 5: 'Maximum Subarray', 6: 'Merge Intervals',
            7: 'LRU Cache', 8: 'Trapping Rain Water'
        };
        
        container.innerHTML = `
            <div style="margin-bottom: 1rem;">
                <div style="background: #f8f9ff; padding: 10px; border-radius: 8px; margin-bottom: 15px;">
                    <strong>📊 Average Score: ${avgCodingScore}%</strong>
                    <progress value="${avgCodingScore}" max="100" style="width: 100%; height: 8px; border-radius: 4px;"></progress>
                </div>
                ${Object.values(latestSubmissions).map(s => `
                    <div style="display: flex; justify-content: space-between; padding: 8px; border-bottom: 1px solid #eee;">
                        <span>${questionNames[s.questionId]}</span>
                        <span style="color: ${s.score >= 70 ? 'green' : 'orange'}; font-weight: bold;">${s.score}%</span>
                    </div>
                `).join('')}
            </div>
            <a href="coding.html" class="btn btn-secondary">View All →</a>
        `;
    }
    
    // Update progress chart
    if (typeof updateProgressChart === 'function') {
        updateProgressChart({
            resume_score: parseInt(resumeScore),
            avg_score: avgCodingScore,
            total_coding_challenges: parseInt(totalCoding)
        });
    }
}

// Listen for storage changes (when code submitted from coding page)
window.addEventListener('storage', function(e) {
    if (e.key === 'codingSubmissions') {
        updateDashboardFromStorage();
    }
});
// ============ Progress Chart ============
let progressChartInstance = null;

function updateProgressChart(stats) {
    console.log("Updating progress chart with:", stats);
    
    const canvas = document.getElementById('progressChart');
    if (!canvas) {
        console.error("Progress chart canvas not found");
        return;
    }
    
    // Calculate coding score
    let codingScore = 0;
    if (stats.coding_scores && stats.coding_scores.length > 0) {
        codingScore = Math.round(stats.coding_scores.reduce((a, b) => a + b, 0) / stats.coding_scores.length);
    } else if (stats.total_coding_challenges) {
        codingScore = Math.min(100, stats.total_coding_challenges * 10);
    }
    
    const scores = [
        stats.resume_score || 0,
        stats.avg_score || 0,
        codingScore
    ];
    
    console.log("Chart scores:", { resume: scores[0], interview: scores[1], coding: scores[2] });
    
    if (progressChartInstance) {
        progressChartInstance.destroy();
    }
    
    progressChartInstance = new Chart(canvas, {
        type: 'bar',
        data: {
            labels: ['Resume Match', 'Interview Avg', 'Coding'],
            datasets: [{
                label: 'Progress (%)',
                data: scores,
                backgroundColor: ['#6366f1', '#8b5cf6', '#a855f7'],
                borderRadius: 8,
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    title: {
                        display: true,
                        text: 'Score (%)'
                    },
                    ticks: {
                        callback: function(value) {
                            return value + '%';
                        }
                    }
                }
            },
            plugins: {
                legend: {
                    position: 'bottom'
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `${context.dataset.label}: ${context.raw}%`;
                        }
                    }
                }
            }
        }
    });
    
    console.log("Chart updated successfully");
}

// ============ Resume Upload ============
function showResumeUpload() {
    const modal = document.getElementById('resumeModal');
    if (modal) modal.style.display = 'flex';
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) modal.style.display = 'none';
    
    const resultDiv = document.getElementById('uploadResult');
    if (resultDiv) resultDiv.innerHTML = '';
    
    const fileInput = document.getElementById('resumeFile');
    if (fileInput) fileInput.value = '';
}

async function uploadResume() {
    const fileInput = document.getElementById('resumeFile');
    const jobDesc = document.getElementById('jobDescription');
    const resultDiv = document.getElementById('uploadResult');
    const scoreDisplay = document.getElementById('scoreDisplay');
    
    if (!fileInput || !fileInput.files || !fileInput.files[0]) {
        if (resultDiv) resultDiv.innerHTML = '<div style="color: red;">❌ Please select a file</div>';
        return;
    }
    
    const file = fileInput.files[0];
    const token = localStorage.getItem('token');
    
    if (!token) {
        if (resultDiv) resultDiv.innerHTML = '<div style="color: red;">❌ Please login first</div>';
        setTimeout(() => window.location.href = 'login.html', 1500);
        return;
    }
    
    if (!file.name.toLowerCase().endsWith('.pdf')) {
        if (resultDiv) resultDiv.innerHTML = '<div style="color: red;">❌ Only PDF files are supported</div>';
        return;
    }
    
    const formData = new FormData();
    formData.append('resume', file);
    formData.append('job_description', jobDesc ? jobDesc.value : '');
    
    if (resultDiv) resultDiv.innerHTML = '<div style="color: #6366f1;">📤 Uploading...</div>';
    if (scoreDisplay) scoreDisplay.style.display = 'none';
    
    try {
        const response = await fetch(`${API_BASE}/upload-resume`, {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${token}` },
            body: formData
        });
        
        const data = await response.json();
        console.log('Upload response:', data);
        
        if (response.ok && data.success) {
            const score = data.match_score || 0;
            const skills = data.matched_skills || [];
            
            // ============ SAVE TO LOCALSTORAGE ============
            // Save latest resume score
            localStorage.setItem('latestResumeScore', score);
            
            // Save to uploaded resumes list
            const uploadedResumes = JSON.parse(localStorage.getItem('uploadedResumes') || '[]');
            uploadedResumes.unshift({
                id: Date.now(),
                file_path: file.name,
                match_score: score,
                uploaded_at: new Date().toISOString()
            });
            // Keep only last 10 resumes
            if (uploadedResumes.length > 10) uploadedResumes.pop();
            localStorage.setItem('uploadedResumes', JSON.stringify(uploadedResumes));
            
            // ============ UPDATE DASHBOARD IMMEDIATELY ============
            // Update resume score display
            const resumeScoreSpan = document.getElementById('resumeScore');
            if (resumeScoreSpan) resumeScoreSpan.innerText = score;
            
            // Update recent resumes
            await loadRecentResumes();
            
            // Update dashboard stats
            await loadDashboardStats();
            
            // Update progress chart
            const submissions = JSON.parse(localStorage.getItem('codingSubmissions') || '[]');
            const codingScores = submissions.map(s => s.score);
            const avgCodingScore = codingScores.length > 0 
                ? Math.round(codingScores.reduce((a, b) => a + b, 0) / codingScores.length)
                : 0;
            
            if (typeof updateProgressChart === 'function') {
                updateProgressChart({
                    resume_score: score,
                    avg_score: avgCodingScore,
                    total_coding_challenges: submissions.length,
                    coding_scores: codingScores
                });
            }
            
            // ============ SHOW SCORE IN MODAL ============
            if (scoreDisplay) scoreDisplay.style.display = 'block';
            document.getElementById('matchScore').innerText = score;
            document.getElementById('matchedSkills').innerText = skills.join(', ') || 'None';
            
            const statusSpan = document.getElementById('matchStatus');
            if (score >= 70) {
                statusSpan.innerHTML = '✅ Shortlisted! Great match!';
                statusSpan.style.color = 'green';
            } else if (score >= 50) {
                statusSpan.innerHTML = '⚠️ Good match, needs improvement';
                statusSpan.style.color = 'orange';
            } else {
                statusSpan.innerHTML = '❌ Low match. Consider updating resume';
                statusSpan.style.color = 'red';
            }
            
            if (resultDiv) {
                resultDiv.innerHTML = `<div style="background: #d1fae5; padding: 0.5rem; border-radius: 8px;">✅ Upload successful! Score: ${score}%</div>`;
            }
            
            // Show success message
            alert(`✅ Resume uploaded! Match Score: ${score}%`);
            
            setTimeout(() => {
                closeModal('resumeModal');
                if (scoreDisplay) scoreDisplay.style.display = 'none';
            }, 3000);
            
        } else {
            if (resultDiv) {
                resultDiv.innerHTML = `<div style="background: #fee2e2; padding: 1rem;">❌ Failed: ${data.error || 'Unknown error'}</div>`;
            }
        }
    } catch (error) {
        console.error('Upload error:', error);
        if (resultDiv) {
            resultDiv.innerHTML = `<div style="background: #fee2e2; padding: 1rem;">❌ Network Error: ${error.message}</div>`;
        }
    }
}

// ============ Page Load ============
document.addEventListener('DOMContentLoaded', () => {
    const page = window.location.pathname;
    console.log('Page loaded:', page);
    
    if (page.includes('dashboard.html')) {
        loadDashboard();
        
        window.onclick = (event) => {
            const modal = document.getElementById('resumeModal');
            if (event.target === modal) closeModal('resumeModal');
        };
        
        const uploadArea = document.getElementById('uploadArea');
        const fileInput = document.getElementById('resumeFile');
        if (uploadArea && fileInput) {
            uploadArea.onclick = () => fileInput.click();
        }
    }
    
    const protectedPages = ['dashboard.html', 'interview.html', 'coding.html'];
    if (protectedPages.some(p => page.includes(p))) {
        if (!isLoggedIn()) {
            window.location.href = 'login.html';
        }
    }
});
// ============ CAMERA & MICROPHONE FUNCTIONS WITH FACE DETECTION ============
let currentStream = null;
let mediaRecorder = null;
let recordedChunks = [];
let faceDetectionInterval = null;
let isInterviewActive = false;
let currentQuestionIndex = 0;
let questionTimer = null;
let timeLeft = 60; // 60 seconds per question
let userAnswers = [];

// Face detection helper (simplified - checks if video has face-like features)
async function checkFacePresence(videoElement) {
    if (!videoElement || !videoElement.videoWidth || videoElement.videoWidth === 0) {
        return false;
    }
    
    // Create canvas to analyze video frame
    const canvas = document.createElement('canvas');
    canvas.width = videoElement.videoWidth;
    canvas.height = videoElement.videoHeight;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
    
    // Get pixel data
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const pixels = imageData.data;
    
    // Simple skin tone detection (rough approximation)
    let skinPixelCount = 0;
    for (let i = 0; i < pixels.length; i += 4) {
        const r = pixels[i];
        const g = pixels[i + 1];
        const b = pixels[i + 2];
        // Simple skin tone range
        if (r > 80 && g > 40 && b > 40 && r > g && r > b && (r - g) > 15) {
            skinPixelCount++;
        }
    }
    
    const skinPercentage = skinPixelCount / (pixels.length / 4);
    return skinPercentage > 0.05; // At least 5% skin tones
}

async function startCameraWithFaceDetection() {
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ 
            video: true, 
            audio: true 
        });
        currentStream = stream;
        const videoElement = document.getElementById('videoElement');
        if (videoElement) {
            videoElement.srcObject = stream;
            
            // Wait for video to load then start face detection
            videoElement.onloadedmetadata = () => {
                videoElement.play();
                startFaceDetection();
            };
        }
        
        updateCameraStatus('✅ Active', 'mic-active');
        updateMicStatus('✅ Active', 'mic-active');
        console.log('Camera and microphone started');
        
        // Show face detection warning if needed
        setTimeout(() => {
            const warningDiv = document.getElementById('faceWarning');
            if (warningDiv) {
                warningDiv.style.display = 'block';
                warningDiv.innerHTML = '📢 Please make sure your face is clearly visible in the camera!';
                setTimeout(() => {
                    warningDiv.style.display = 'none';
                }, 5000);
            }
        }, 2000);
        
    } catch (error) {
        console.error('Error accessing camera/mic:', error);
        updateCameraStatus('❌ Denied', 'mic-inactive');
        updateMicStatus('❌ Denied', 'mic-inactive');
        alert('Please allow camera and microphone access for interview features.');
    }
}

function startFaceDetection() {
    if (faceDetectionInterval) clearInterval(faceDetectionInterval);
    
    faceDetectionInterval = setInterval(async () => {
        if (!isInterviewActive) return;
        
        const videoElement = document.getElementById('videoElement');
        if (videoElement && videoElement.readyState === 4) {
            const faceDetected = await checkFacePresence(videoElement);
            const warningDiv = document.getElementById('faceWarning');
            
            if (!faceDetected && warningDiv) {
                warningDiv.style.display = 'block';
                warningDiv.innerHTML = '⚠️ WARNING: Face not detected! Please look at the camera.';
                warningDiv.style.backgroundColor = '#fee2e2';
                warningDiv.style.color = '#dc2626';
                warningDiv.style.padding = '10px';
                warningDiv.style.borderRadius = '8px';
                warningDiv.style.marginBottom = '10px';
                
                // Auto hide after 3 seconds
                setTimeout(() => {
                    if (warningDiv && warningDiv.style.display === 'block') {
                        warningDiv.style.display = 'none';
                    }
                }, 3000);
            } else if (faceDetected && warningDiv) {
                warningDiv.style.display = 'none';
            }
        }
    }, 3000); // Check every 3 seconds
}

function updateCameraStatus(text, className) {
    const cameraStatus = document.getElementById('cameraStatus');
    if (cameraStatus) {
        cameraStatus.innerHTML = `📷 Camera: ${text}`;
        cameraStatus.className = `mic-status ${className}`;
    }
}

function updateMicStatus(text, className) {
    const micStatus = document.getElementById('micStatus');
    if (micStatus) {
        micStatus.innerHTML = `🎤 Microphone: ${text}`;
        micStatus.className = `mic-status ${className}`;
    }
}

function stopCamera() {
    isInterviewActive = false;
    if (faceDetectionInterval) {
        clearInterval(faceDetectionInterval);
        faceDetectionInterval = null;
    }
    if (questionTimer) {
        clearInterval(questionTimer);
        questionTimer = null;
    }
    
    if (currentStream) {
        currentStream.getTracks().forEach(track => track.stop());
        currentStream = null;
        const videoElement = document.getElementById('videoElement');
        if (videoElement) {
            videoElement.srcObject = null;
        }
        updateCameraStatus('Off', 'mic-inactive');
        updateMicStatus('Off', 'mic-inactive');
    }
}

async function testMicrophone() {
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        updateMicStatus('✅ Working!', 'mic-active');
        setTimeout(() => {
            stream.getTracks().forEach(track => track.stop());
            if (currentStream) {
                updateMicStatus('Ready', 'mic-active');
            } else {
                updateMicStatus('Tested', 'mic-inactive');
            }
        }, 2000);
    } catch (error) {
        updateMicStatus('❌ Not working', 'mic-inactive');
        alert('Microphone test failed. Please check permissions.');
    }
}

function startRecording() {
    if (!currentStream) {
        alert('Please start camera first!');
        return;
    }
    
    recordedChunks = [];
    mediaRecorder = new MediaRecorder(currentStream);
    
    mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
            recordedChunks.push(event.data);
        }
    };
    
    mediaRecorder.onstop = () => {
        const blob = new Blob(recordedChunks, { type: 'video/webm' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'interview-recording-' + new Date().toISOString() + '.webm';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        const recordingStatus = document.getElementById('recordingStatus');
        if (recordingStatus) {
            recordingStatus.innerHTML = '✅ Recording saved!';
            recordingStatus.style.color = 'green';
        }
    };
    
    mediaRecorder.start();
    const recordingStatus = document.getElementById('recordingStatus');
    if (recordingStatus) {
        recordingStatus.innerHTML = '🔴 RECORDING IN PROGRESS...';
        recordingStatus.style.color = 'red';
    }
}

function stopRecording() {
    if (mediaRecorder && mediaRecorder.state === 'recording') {
        mediaRecorder.stop();
        const recordingStatus = document.getElementById('recordingStatus');
        if (recordingStatus) {
            recordingStatus.innerHTML = '⏹️ Recording stopped. Saved!';
            recordingStatus.style.color = 'green';
        }
    } else {
        alert('No recording in progress');
    }
}

// ============ AI INTERVIEW FUNCTIONS WITH TIMING ============
let currentSessionId = null;
let currentQuestions = [];
let currentQuestionStartTime = null;

function startInterview() {
    console.log("🎤 Start Interview clicked!");
    
    // First check if camera is active
    if (!currentStream) {
        alert('⚠️ Please start camera first before starting the interview!');
        return;
    }
    
    const jobRole = document.getElementById('jobRole')?.value || 'Software Developer';
    const experienceLevel = document.getElementById('experienceLevel')?.value || 'Mid';
    
    console.log(`Role: ${jobRole}, Level: ${experienceLevel}`);
    
    const token = localStorage.getItem('token');
    
    if (!token) {
        alert('Please login first!');
        window.location.href = 'login.html';
        return;
    }
    
    // Show instructions first
    showInterviewInstructions(jobRole, experienceLevel);
}

function showInterviewInstructions(jobRole, experienceLevel) {
    const setupSection = document.getElementById('setupSection');
    const instructionsDiv = document.createElement('div');
    instructionsDiv.id = 'instructionsSection';
    instructionsDiv.className = 'card';
    instructionsDiv.innerHTML = `
        <h3>📋 Interview Instructions</h3>
        <div style="background: #e8f4f8; padding: 15px; border-radius: 10px; margin: 15px 0;">
            <p><strong>🎯 Role:</strong> ${jobRole}</p>
            <p><strong>📊 Level:</strong> ${experienceLevel}</p>
            <p><strong>⏱️ Time per question:</strong> 60 seconds</p>
            <p><strong>📹 Camera:</strong> Please keep your face visible</p>
            <p><strong>🎤 Microphone:</strong> Speak clearly</p>
        </div>
        <h4>Important Guidelines:</h4>
        <ul style="margin: 15px 0; padding-left: 20px;">
            <li>✅ Make sure your face is clearly visible in the camera</li>
            <li>✅ Speak clearly and confidently</li>
            <li>✅ You have 60 seconds to answer each question</li>
            <li>✅ After time runs out, next question will start automatically</li>
            <li>✅ Click "Next Question" to proceed early</li>
        </ul>
        <div style="display: flex; gap: 1rem; margin-top: 20px;">
            <button class="btn btn-primary" onclick="startInterviewQuestions('${jobRole}', '${experienceLevel}')">Start Interview Now</button>
            <button class="btn btn-outline" onclick="cancelInstructions()">Cancel</button>
        </div>
    `;
    
    if (setupSection) {
        setupSection.style.display = 'none';
        setupSection.parentNode.insertBefore(instructionsDiv, setupSection.nextSibling);
    }
}

function cancelInstructions() {
    const instructionsSection = document.getElementById('instructionsSection');
    const setupSection = document.getElementById('setupSection');
    if (instructionsSection) instructionsSection.remove();
    if (setupSection) setupSection.style.display = 'block';
}

function startInterviewQuestions(jobRole, experienceLevel) {
    // Remove instructions section
    const instructionsSection = document.getElementById('instructionsSection');
    if (instructionsSection) instructionsSection.remove();
    
    // Generate questions
    generateQuestionsByRole(jobRole, experienceLevel);
    
    // Show interview section
    const interviewSection = document.getElementById('interviewSection');
    const resultsSection = document.getElementById('resultsSection');
    
    if (interviewSection) interviewSection.style.display = 'block';
    if (resultsSection) resultsSection.style.display = 'none';
    
    isInterviewActive = true;
    currentQuestionIndex = 0;
    userAnswers = [];
    
    // Start first question
    displayCurrentQuestion();
}

function generateQuestionsByRole(role, level) {
    const questionsDB = {
        'Software Developer': {
            'Beginner': [
                "What is the difference between let, const, and var in JavaScript?",
                "Explain what REST API is and how it works.",
                "What is version control and why is it important?",
                "Explain the difference between SQL and NoSQL databases.",
                "What are the basic principles of Object-Oriented Programming?"
            ],
            'Mid': [
                "Explain the concept of hoisting in JavaScript.",
                "How would you optimize a slow-loading web page?",
                "What is the difference between authentication and authorization?",
                "Explain how you would design a URL shortening service.",
                "What are microservices and their advantages?"
            ],
            'Senior': [
                "Describe a complex system you designed. What challenges did you face?",
                "How do you ensure code quality in a large team?",
                "Explain the CAP theorem and its implications.",
                "How would you migrate a monolithic app to microservices?",
                "Describe your experience with system architecture and scalability."
            ]
        },
        'Data Scientist': {
            'Beginner': [
                "What is the difference between supervised and unsupervised learning?",
                "Explain what p-value means in statistics.",
                "What is the purpose of train-test split?",
                "Explain bias-variance tradeoff.",
                "What is the difference between correlation and causation?"
            ],
            'Mid': [
                "How do you handle imbalanced datasets?",
                "Explain how gradient descent works.",
                "What is the difference between bagging and boosting?",
                "How do you detect overfitting?",
                "Explain feature engineering and its importance."
            ],
            'Senior': [
                "Describe an end-to-end ML project you led.",
                "How do you deploy ML models in production?",
                "Explain how to handle concept drift in ML models.",
                "What is your approach to model interpretability?",
                "How do you ensure reproducibility in ML experiments?"
            ]
        },
        'DevOps Engineer': {
            'Beginner': [
                "What is CI/CD and why is it important?",
                "Explain the difference between containers and virtual machines.",
                "What is infrastructure as code?",
                "Explain the basic concepts of Kubernetes.",
                "What is the difference between Git and Jenkins?"
            ],
            'Mid': [
                "How do you set up a complete CI/CD pipeline?",
                "Explain blue-green deployment strategy.",
                "How do you monitor system health in production?",
                "What tools do you use for logging and monitoring?",
                "Explain how to handle secrets management."
            ],
            'Senior': [
                "Design a high-availability architecture on AWS.",
                "How do you implement zero-downtime deployments?",
                "Explain disaster recovery strategies for cloud infrastructure.",
                "How do you optimize cloud costs while maintaining performance?",
                "Describe a challenging production issue you resolved."
            ]
        },
        'Product Manager': {
            'Beginner': [
                "Tell me about a product you helped launch.",
                "How do you prioritize features?",
                "How do you gather customer feedback?",
                "What metrics do you track for product success?",
                "How do you work with engineering teams?"
            ],
            'Mid': [
                "Describe your product roadmap process.",
                "How do you handle competing priorities?",
                "Explain a time you had to pivot product strategy.",
                "How do you validate product ideas?",
                "What's your approach to A/B testing?"
            ],
            'Senior': [
                "Describe a product failure and what you learned.",
                "How do you align product strategy with business goals?",
                "How do you manage stakeholders with conflicting interests?",
                "Explain your data-driven decision making process.",
                "How do you build and lead product teams?"
            ]
        }
    };
    
    let questions = questionsDB[role]?.[level] || questionsDB['Software Developer']['Mid'];
    currentQuestions = questions.slice(0, 5);
}

function displayCurrentQuestion() {
    if (currentQuestionIndex >= currentQuestions.length) {
        finishInterview();
        return;
    }
    
    const container = document.getElementById('questionsContainer');
    if (!container) return;
    
    const question = currentQuestions[currentQuestionIndex];
    const questionNumber = currentQuestionIndex + 1;
    
    // Reset timer
    if (questionTimer) clearInterval(questionTimer);
    timeLeft = 60;
    currentQuestionStartTime = Date.now();
    
    container.innerHTML = `
        <div class="card" style="margin-bottom: 1rem;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                <h4>Question ${questionNumber} of ${currentQuestions.length}</h4>
                <div style="background: #6366f1; color: white; padding: 5px 15px; border-radius: 20px;">
                    ⏱️ Time: <span id="timerDisplay">01:00</span>
                </div>
            </div>
            <p style="margin-bottom: 1rem; font-size: 1.1rem;">${escapeHtml(question)}</p>
            <div class="form-group">
                <label>Your Answer (Speak or type below):</label>
                <textarea id="currentAnswer" rows="4" placeholder="Type your answer here... (or speak into microphone)" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 5px;"></textarea>
            </div>
            <div style="display: flex; gap: 1rem; margin-top: 1rem;">
                <button class="btn btn-primary" onclick="saveAndNext()">Save & Next Question →</button>
                <button class="btn btn-secondary" onclick="startVoiceInput()">🎤 Speak Answer</button>
            </div>
            <div id="voiceStatus" style="margin-top: 10px; font-size: 12px; color: #666;"></div>
        </div>
        <div class="progress-bar" style="margin-top: 1rem;">
            <div class="progress-fill" id="progressFill" style="width: ${(currentQuestionIndex / currentQuestions.length) * 100}%;"></div>
        </div>
    `;
    
    // Start timer
    startTimer();
    
    // Auto-start recording when question appears
    if (!mediaRecorder || mediaRecorder.state !== 'recording') {
        startRecording();
    }
}

function startTimer() {
    questionTimer = setInterval(() => {
        if (timeLeft <= 0) {
            // Time's up - auto save and next
            clearInterval(questionTimer);
            alert('⏰ Time\'s up for this question! Moving to next question...');
            saveAndNext();
        } else {
            timeLeft--;
            const minutes = Math.floor(timeLeft / 60);
            const seconds = timeLeft % 60;
            const timerDisplay = document.getElementById('timerDisplay');
            if (timerDisplay) {
                timerDisplay.innerText = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
            }
            
            // Warning when 10 seconds left
            if (timeLeft === 10) {
                const timerDisplayEl = document.getElementById('timerDisplay');
                if (timerDisplayEl) {
                    timerDisplayEl.style.color = '#ef4444';
                    timerDisplayEl.style.fontWeight = 'bold';
                }
                const voiceStatus = document.getElementById('voiceStatus');
                if (voiceStatus) {
                    voiceStatus.innerHTML = '⚠️ Only 10 seconds left!';
                    voiceStatus.style.color = '#ef4444';
                }
            }
        }
    }, 1000);
}

function saveAndNext() {
    if (questionTimer) clearInterval(questionTimer);
    
    const answerTextarea = document.getElementById('currentAnswer');
    const answer = answerTextarea ? answerTextarea.value : '';
    
    // Save answer
    userAnswers.push({
        question: currentQuestions[currentQuestionIndex],
        answer: answer,
        timeTaken: 60 - timeLeft,
        timestamp: new Date().toISOString()
    });
    
    currentQuestionIndex++;
    
    if (currentQuestionIndex < currentQuestions.length) {
        displayCurrentQuestion();
    } else {
        finishInterview();
    }
}

function startVoiceInput() {
    const voiceStatus = document.getElementById('voiceStatus');
    if (!voiceStatus) return;
    
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
        voiceStatus.innerHTML = '❌ Speech recognition not supported in this browser. Please use Chrome.';
        voiceStatus.style.color = '#ef4444';
        return;
    }
    
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.lang = 'en-US';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    
    voiceStatus.innerHTML = '🎤 Listening... Speak your answer now.';
    voiceStatus.style.color = '#6366f1';
    
    recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        const answerTextarea = document.getElementById('currentAnswer');
        if (answerTextarea) {
            const currentText = answerTextarea.value;
            answerTextarea.value = currentText ? currentText + ' ' + transcript : transcript;
        }
        voiceStatus.innerHTML = '✅ Voice captured! You can edit the text if needed.';
        voiceStatus.style.color = '#22c55e';
        setTimeout(() => {
            voiceStatus.innerHTML = '';
        }, 2000);
    };
    
    recognition.onerror = (event) => {
        voiceStatus.innerHTML = `❌ Error: ${event.error}. Please try again or type your answer.`;
        voiceStatus.style.color = '#ef4444';
    };
    
    recognition.start();
}

function finishInterview() {
    isInterviewActive = false;
    if (questionTimer) clearInterval(questionTimer);
    
    if (mediaRecorder && mediaRecorder.state === 'recording') {
        stopRecording();
    }
    
    const results = [];
    let totalScore = 0;
    
    for (let i = 0; i < userAnswers.length; i++) {
        const answer = userAnswers[i].answer;
        let score = 50;
        let comment = '';
        
        if (!answer || answer.trim().length < 10) {
            score = 20;
            comment = "Your answer was too brief. Please elaborate more.";
        } else if (answer.length < 50) {
            score = 40;
            comment = "Good start, but add more detail.";
        } else if (answer.length < 150) {
            score = 70;
            comment = "Good answer with solid points.";
        } else {
            score = 90;
            comment = "Excellent! Detailed answer.";
        }
        
        totalScore += score;
        results.push({
            question: userAnswers[i].question,
            answer: answer,
            score: score,
            comment: comment,
            timeTaken: userAnswers[i].timeTaken
        });
    }
    
    const averageScore = Math.round(totalScore / currentQuestions.length);
    
    // ============ SAVE INTERVIEW SCORE TO LOCALSTORAGE ============
    const userId = localStorage.getItem('userId') || 'default';
    const interviewScores = JSON.parse(localStorage.getItem(`interviewScores_${userId}`) || '[]');
    interviewScores.push({
        id: Date.now(),
        score: averageScore,
        totalQuestions: currentQuestions.length,
        date: new Date().toISOString(),
        role: document.getElementById('jobRole')?.value || 'Software Developer'
    });
    localStorage.setItem(`interviewScores_${userId}`, JSON.stringify(interviewScores));
    
    // Also save to global for dashboard
    localStorage.setItem('latestInterviewScore', averageScore);
    localStorage.setItem('totalInterviews', interviewScores.length);
    
    console.log(`✅ Interview saved! Score: ${averageScore}%`);
    
    // ============ UPDATE DASHBOARD STATS ============
    if (typeof loadDashboardStats === 'function') {
        loadDashboardStats();
    }
    
    // Show results
    const interviewSection = document.getElementById('interviewSection');
    const resultsSection = document.getElementById('resultsSection');
    
    if (interviewSection) interviewSection.style.display = 'none';
    if (resultsSection) resultsSection.style.display = 'block';
    
    const resultsContent = document.getElementById('resultsContent');
    if (resultsContent) {
        resultsContent.innerHTML = `
            <div style="text-align: center; margin-bottom: 2rem;">
                <div style="font-size: 3rem;">${averageScore >= 70 ? '🎉' : '📚'}</div>
                <h2>Total Score: ${averageScore}%</h2>
                <p>${averageScore >= 70 ? 'Great job! Keep practicing!' : 'Good attempt! Review the feedback.'}</p>
                <p style="font-size: 14px; color: #6366f1;">✅ Score saved to Dashboard!</p>
            </div>
            ${results.map((r, idx) => `
                <div style="border-top: 1px solid #e0e0e0; padding: 1rem 0;">
                    <strong>Q${idx + 1}:</strong> ${escapeHtml(r.question)}<br>
                    <strong>Time taken:</strong> ${r.timeTaken} seconds<br>
                    <strong>Score:</strong> ${r.score}%<br>
                    <strong>Feedback:</strong> ${escapeHtml(r.comment)}
                </div>
            `).join('')}
        `;
    }
}

function resetInterview() {
    isInterviewActive = false;
    if (questionTimer) clearInterval(questionTimer);
    
    currentSessionId = null;
    currentQuestions = [];
    currentQuestionIndex = 0;
    userAnswers = [];
    
    const setupSection = document.getElementById('setupSection');
    const interviewSection = document.getElementById('interviewSection');
    const resultsSection = document.getElementById('resultsSection');
    const instructionsSection = document.getElementById('instructionsSection');
    
    if (instructionsSection) instructionsSection.remove();
    if (setupSection) setupSection.style.display = 'block';
    if (interviewSection) interviewSection.style.display = 'none';
    if (resultsSection) resultsSection.style.display = 'none';
    
    // Clear answers
    const answerTextarea = document.getElementById('currentAnswer');
    if (answerTextarea) answerTextarea.value = '';
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
// ============ CODING FUNCTIONS ============
let currentDifficulty = 'all';
let allQuestions = [
    { id: 1, title: 'Two Sum', difficulty: 'easy', description: 'Given an array of integers nums and an integer target, return indices of the two numbers that add up to target.', starterCode: { python: 'def two_sum(nums, target):\n    # Write your solution here\n    pass', javascript: 'function twoSum(nums, target) {\n    // Write your solution here\n}', java: 'public int[] twoSum(int[] nums, int target) {\n    // Write your solution here\n    return new int[0];\n}' } },
    { id: 2, title: 'Reverse String', difficulty: 'easy', description: 'Write a function that reverses a string.', starterCode: { python: 'def reverse_string(s):\n    # Write your solution here\n    pass', javascript: 'function reverseString(s) {\n    // Write your solution here\n}', java: 'public void reverseString(char[] s) {\n    // Write your solution here\n}' } },
    { id: 3, title: 'Fizz Buzz', difficulty: 'easy', description: 'Write a program that outputs Fizz for multiples of 3, Buzz for multiples of 5.', starterCode: { python: 'def fizz_buzz(n):\n    result = []\n    # Write your solution here\n    return result', javascript: 'function fizzBuzz(n) {\n    let result = [];\n    // Write your solution here\n    return result;\n}', java: 'public List<String> fizzBuzz(int n) {\n    List<String> result = new ArrayList<>();\n    // Write your solution here\n    return result;\n}' } },
    { id: 4, title: 'Valid Parentheses', difficulty: 'medium', description: 'Given a string containing parentheses, determine if it is valid.', starterCode: { python: 'def is_valid(s):\n    stack = []\n    # Write your solution here\n    return False', javascript: 'function isValid(s) {\n    let stack = [];\n    // Write your solution here\n    return false;\n}', java: 'public boolean isValid(String s) {\n    Stack<Character> stack = new Stack<>();\n    // Write your solution here\n    return false;\n}' } },
    { id: 5, title: 'Maximum Subarray', difficulty: 'medium', description: 'Find the contiguous subarray with the largest sum.', starterCode: { python: 'def max_subarray(nums):\n    # Write your solution using Kadane\'s algorithm\n    pass', javascript: 'function maxSubArray(nums) {\n    // Write your solution using Kadane\'s algorithm\n}', java: 'public int maxSubArray(int[] nums) {\n    // Write your solution using Kadane\'s algorithm\n    return 0;\n}' } },
    { id: 6, title: 'Merge Intervals', difficulty: 'medium', description: 'Merge all overlapping intervals.', starterCode: { python: 'def merge_intervals(intervals):\n    # Write your solution here\n    pass', javascript: 'function merge(intervals) {\n    // Write your solution here\n}', java: 'public int[][] merge(int[][] intervals) {\n    // Write your solution here\n    return new int[0][];\n}' } },
    { id: 7, title: 'LRU Cache', difficulty: 'hard', description: 'Design and implement an LRU cache.', starterCode: { python: 'class LRUCache:\n    def __init__(self, capacity):\n        pass\n    def get(self, key):\n        pass\n    def put(self, key, value):\n        pass', javascript: 'class LRUCache {\n    constructor(capacity) {\n        // Write your solution here\n    }\n    get(key) {\n        // Write your solution here\n    }\n    put(key, value) {\n        // Write your solution here\n    }\n}', java: 'class LRUCache {\n    public LRUCache(int capacity) {\n        // Write your solution here\n    }\n    public int get(int key) {\n        // Write your solution here\n    }\n    public void put(int key, int value) {\n        // Write your solution here\n    }\n}' } },
    { id: 8, title: 'Trapping Rain Water', difficulty: 'hard', description: 'Given n non-negative integers representing an elevation map, compute how much water it can trap.', starterCode: { python: 'def trap(height):\n    # Write your solution here\n    pass', javascript: 'function trap(height) {\n    // Write your solution here\n}', java: 'public int trap(int[] height) {\n    // Write your solution here\n    return 0;\n}' } }
];

let currentQuestion = null;

function filterQuestions(difficulty) {
    currentDifficulty = difficulty;
    
    // Update active button
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.textContent.toLowerCase() === difficulty || (difficulty === 'all' && btn.textContent === 'All')) {
            btn.classList.add('active');
        }
    });
    
    loadQuestionsList();
}

function loadQuestionsList() {
    const container = document.getElementById('questionsList');
    if (!container) return;
    
    let filteredQuestions = allQuestions;
    if (currentDifficulty !== 'all') {
        filteredQuestions = allQuestions.filter(q => q.difficulty === currentDifficulty);
    }
    
    if (filteredQuestions.length === 0) {
        container.innerHTML = '<p style="padding: 20px; text-align: center;">No questions found for this difficulty.</p>';
        return;
    }
    
    container.innerHTML = filteredQuestions.map(q => `
        <div class="question-item" onclick="selectQuestion(${q.id})">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <strong>${escapeHtml(q.title)}</strong>
                <span class="difficulty-${q.difficulty}">${q.difficulty.toUpperCase()}</span>
            </div>
            <p style="font-size: 12px; color: #666; margin-top: 5px;">${escapeHtml(q.description.substring(0, 80))}...</p>
        </div>
    `).join('');
}

function selectQuestion(questionId) {
    currentQuestion = allQuestions.find(q => q.id === questionId);
    if (!currentQuestion) return;
    
    // Update question details
    const detailsDiv = document.getElementById('questionDetails');
    if (detailsDiv) {
        detailsDiv.innerHTML = `
            <h3>${escapeHtml(currentQuestion.title)}</h3>
            <p>${escapeHtml(currentQuestion.description)}</p>
            <span class="difficulty-${currentQuestion.difficulty}" style="font-weight: bold;">${currentQuestion.difficulty.toUpperCase()}</span>
        `;
    }
    
    updateStarterCode();
}

function updateStarterCode() {
    const language = document.getElementById('language')?.value || 'python';
    const editor = document.getElementById('codeEditor');
    
    if (editor && currentQuestion) {
        editor.value = currentQuestion.starterCode[language] || currentQuestion.starterCode.python;
    }
}

function runCode() {
    const code = document.getElementById('codeEditor')?.value || '';
    const outputDiv = document.getElementById('codeOutput');
    
    if (outputDiv) {
        outputDiv.innerHTML = `▶️ Code executed!\n\n📝 Code length: ${code.length} characters\n\n💡 Tip: Click "Submit Solution" to get your score!`;
    }
}

function submitCode() {
    const code = document.getElementById('codeEditor')?.value || '';
    const language = document.getElementById('language')?.value || 'python';
    const outputDiv = document.getElementById('codeOutput');
    
    if (!currentQuestion) {
        if (outputDiv) outputDiv.innerHTML = '<div style="color: #ef4444;">❌ Please select a question first!</div>';
        return;
    }
    
    outputDiv.innerHTML = '<div style="color: #ffcc00;">📤 Submitting solution...</div>';
    
    setTimeout(() => {
        let score = 50;
        let feedback = '';
        let output = '';
        
        if (code.trim().length === 0) {
            score = 0;
            feedback = 'Please write some code before submitting.';
            output = 'No code written.';
        } else if (code.length < 50) {
            score = 30;
            feedback = 'Your solution seems incomplete. Try to write a complete function.';
            output = 'Code too short. Please write a complete solution.';
        } else if (code.includes('return')) {
            score = 75;
            feedback = 'Good work! Your code has the right structure.';
            if (currentQuestion.id === 1) {
                output = 'Example: two_sum([2,7,11,15], 9) → [0,1]';
            } else if (currentQuestion.id === 2) {
                output = 'Example: reverse_string("hello") → "olleh"';
            } else if (currentQuestion.id === 3) {
                output = 'Example: fizz_buzz(5) → ["1","2","Fizz","4","Buzz"]';
            } else {
                output = 'Function defined successfully!';
            }
        } else {
            score = 60;
            feedback = 'Make sure your function returns the correct value.';
            output = 'Make sure to include a return statement.';
        }
        
        if (currentQuestion.id === 1 && (code.includes('dict') || code.includes('map'))) {
            score += 10;
            feedback += ' Good use of hash map!';
        }
        if (currentQuestion.id === 4 && code.includes('stack')) {
            score += 10;
            feedback += ' Good use of stack!';
        }
        
        score = Math.min(100, score);
        
        outputDiv.innerHTML = `
            <div style="background: #1e1e1e; color: #d4d4d4; padding: 1rem; border-radius: 8px;">
                <strong>▶️ OUTPUT:</strong><br>
                <pre style="background: #2d2d2d; padding: 10px; border-radius: 5px;">${output}</pre>
                <hr>
                🎯 Score: <span style="color: #22c55e; font-weight: bold;">${score}%</span><br>
                💬 Feedback: ${feedback}<br>
                ${score >= 70 ? '✅ Great job!' : '📚 Keep practicing!'}
            </div>
        `;
        
        // ============ IMPORTANT: Save to localStorage and Update Dashboard ============
        const submissions = JSON.parse(localStorage.getItem('codingSubmissions') || '[]');
        submissions.push({
            questionId: currentQuestion.id,
            title: currentQuestion.title,
            score: score,
            language: language,
            date: new Date().toISOString()
        });
        localStorage.setItem('codingSubmissions', JSON.stringify(submissions));
        
        // Update coding count in localStorage for dashboard
        const totalCoding = submissions.length;
        localStorage.setItem('totalCodingChallenges', totalCoding);
        
        // Calculate average coding score
        const allScores = submissions.map(s => s.score);
        const avgCodingScore = allScores.length > 0 
            ? Math.round(allScores.reduce((a, b) => a + b, 0) / allScores.length)
            : 0;
        localStorage.setItem('avgCodingScore', avgCodingScore);
        
        // If dashboard is open, update it
        if (typeof window.updateDashboardFromStorage === 'function') {
            window.updateDashboardFromStorage();
        }
        
        alert(`✅ Code submitted! Score: ${score}%`);
    }, 800);
}
// ============ CAMERA & MICROPHONE FUNCTIONS (CORRECTED) ============

// Main Camera Function - HTML button वरून हाच call होईल
async function startCamera() {
    console.log("📷 startCamera() called - Starting camera...");
    
    const videoElement = document.getElementById('videoElement');
    const cameraStatus = document.getElementById('cameraStatus');
    const micStatus = document.getElementById('micStatus');
    
    if (!videoElement) {
        console.error("videoElement not found!");
        alert("Error: Video element not found. Please refresh the page.");
        return;
    }
    
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        alert("Your browser does not support camera access. Please use Chrome or Edge.");
        return;
    }
    
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ 
            video: { width: { ideal: 640 }, height: { ideal: 480 } }, 
            audio: true 
        });
        
        currentStream = stream;
        videoElement.srcObject = stream;
        
        if (cameraStatus) {
            cameraStatus.innerHTML = '📷 Camera: ✅ Active';
            cameraStatus.className = 'mic-status mic-active';
        }
        if (micStatus) {
            micStatus.innerHTML = '🎤 Microphone: ✅ Active';
            micStatus.className = 'mic-status mic-active';
        }
        
        console.log("✅ Camera started successfully");
        
        // Start face detection after camera is ready
        setTimeout(() => {
            startFaceDetection();
        }, 2000);
        
    } catch (error) {
        console.error("Camera error:", error);
        
        let errorMsg = "Could not start camera: ";
        if (error.name === 'NotAllowedError') {
            errorMsg += "Please allow camera access in browser settings.";
        } else if (error.name === 'NotFoundError') {
            errorMsg += "No camera found on your device.";
        } else {
            errorMsg += error.message;
        }
        
        if (cameraStatus) {
            cameraStatus.innerHTML = '📷 Camera: ❌ Failed';
            cameraStatus.className = 'mic-status mic-inactive';
        }
        alert(errorMsg);
    }
}

// Stop Camera Function
function stopCamera() {
    console.log("⏹️ stopCamera() called");
    
    if (currentStream) {
        currentStream.getTracks().forEach(track => track.stop());
        currentStream = null;
        
        const videoElement = document.getElementById('videoElement');
        if (videoElement) {
            videoElement.srcObject = null;
        }
        
        const cameraStatus = document.getElementById('cameraStatus');
        const micStatus = document.getElementById('micStatus');
        
        if (cameraStatus) {
            cameraStatus.innerHTML = '📷 Camera: Off';
            cameraStatus.className = 'mic-status mic-inactive';
        }
        if (micStatus) {
            micStatus.innerHTML = '🎤 Microphone: Off';
            micStatus.className = 'mic-status mic-inactive';
        }
        
        console.log("Camera stopped");
    }
}

// Test Microphone Function
async function testMicrophone() {
    console.log("🎤 testMicrophone() called");
    
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const micStatus = document.getElementById('micStatus');
        
        if (micStatus) {
            micStatus.innerHTML = '🎤 Microphone: ✅ Working!';
            micStatus.className = 'mic-status mic-active';
        }
        
        setTimeout(() => {
            stream.getTracks().forEach(track => track.stop());
            if (!currentStream && micStatus) {
                micStatus.innerHTML = '🎤 Microphone: Tested';
                micStatus.className = 'mic-status mic-inactive';
            }
        }, 2000);
        
    } catch (error) {
        const micStatus = document.getElementById('micStatus');
        if (micStatus) {
            micStatus.innerHTML = '🎤 Microphone: ❌ Failed';
            micStatus.className = 'mic-status mic-inactive';
        }
        alert("Microphone test failed. Please check permissions.");
    }
}

// Recording Functions
function startRecording() {
    if (!currentStream) {
        alert('Please start camera first!');
        return;
    }
    
    recordedChunks = [];
    mediaRecorder = new MediaRecorder(currentStream);
    
    mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
            recordedChunks.push(event.data);
        }
    };
    
    mediaRecorder.onstop = () => {
        const blob = new Blob(recordedChunks, { type: 'video/webm' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'interview-recording-' + new Date().toISOString() + '.webm';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        const recordingStatus = document.getElementById('recordingStatus');
        if (recordingStatus) {
            recordingStatus.innerHTML = '✅ Recording saved!';
            recordingStatus.style.color = 'green';
        }
    };
    
    mediaRecorder.start();
    const recordingStatus = document.getElementById('recordingStatus');
    if (recordingStatus) {
        recordingStatus.innerHTML = '🔴 RECORDING IN PROGRESS...';
        recordingStatus.style.color = 'red';
    }
}

function stopRecording() {
    if (mediaRecorder && mediaRecorder.state === 'recording') {
        mediaRecorder.stop();
        const recordingStatus = document.getElementById('recordingStatus');
        if (recordingStatus) {
            recordingStatus.innerHTML = '⏹️ Recording stopped. Saved!';
            recordingStatus.style.color = 'green';
        }
    } else {
        alert('No recording in progress');
    }
}

// Face Detection Functions
function startFaceDetection() {
    if (faceDetectionInterval) clearInterval(faceDetectionInterval);
    
    faceDetectionInterval = setInterval(async () => {
        if (!isInterviewActive) return;
        
        const videoElement = document.getElementById('videoElement');
        const warningDiv = document.getElementById('faceWarning');
        
        if (videoElement && videoElement.readyState === 4 && warningDiv) {
            // Simple face presence check
            const hasVideo = videoElement.videoWidth > 0 && videoElement.videoHeight > 0;
            
            if (!hasVideo) {
                warningDiv.style.display = 'block';
                warningDiv.innerHTML = '⚠️ WARNING: Face not detected! Please look at the camera.';
                warningDiv.style.backgroundColor = '#fee2e2';
                warningDiv.style.color = '#dc2626';
                warningDiv.style.padding = '10px';
                warningDiv.style.borderRadius = '8px';
                warningDiv.style.marginBottom = '10px';
                
                setTimeout(() => {
                    if (warningDiv) warningDiv.style.display = 'none';
                }, 3000);
            } else if (warningDiv) {
                warningDiv.style.display = 'none';
            }
        }
    }, 5000);
}

function updateCameraStatus(text, className) {
    const cameraStatus = document.getElementById('cameraStatus');
    if (cameraStatus) {
        cameraStatus.innerHTML = `📷 Camera: ${text}`;
        cameraStatus.className = `mic-status ${className}`;
    }
}

function updateMicStatus(text, className) {
    const micStatus = document.getElementById('micStatus');
    if (micStatus) {
        micStatus.innerHTML = `🎤 Microphone: ${text}`;
        micStatus.className = `mic-status ${className}`;
    }
}
// ============ PROFESSIONAL GIRL AVATAR WITH VOICE ============

// Get user name
function getCurrentUserName() {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    return user.name || 'Guest';
}

// Professional Avatar Animation
function animateAvatar(state) {
    const avatar = document.getElementById('aiAvatar');
    const avatarEmoji = document.getElementById('avatarEmoji');
    const avatarStatus = document.getElementById('avatarStatus');
    
    if (!avatar) return;
    
    switch(state) {
        case 'speaking':
            avatar.style.transform = 'scale(1.1)';
            avatar.style.boxShadow = '0 0 25px rgba(99, 102, 241, 0.6)';
            if (avatarEmoji) avatarEmoji.innerHTML = '👩‍💼🎤';
            if (avatarStatus) {
                avatarStatus.innerHTML = '🎤 Speaking...';
                avatarStatus.style.backgroundColor = '#e0e7ff';
            }
            break;
        case 'listening':
            avatar.style.transform = 'scale(1.05)';
            avatar.style.boxShadow = '0 0 20px rgba(168, 85, 247, 0.5)';
            if (avatarEmoji) avatarEmoji.innerHTML = '👩‍💼🎧';
            if (avatarStatus) {
                avatarStatus.innerHTML = '🎧 Listening...';
                avatarStatus.style.backgroundColor = '#fae8ff';
            }
            break;
        case 'thinking':
            avatar.style.transform = 'scale(1.02)';
            avatar.style.boxShadow = '0 0 15px rgba(99, 102, 241, 0.4)';
            if (avatarEmoji) avatarEmoji.innerHTML = '👩‍💼💭';
            if (avatarStatus) {
                avatarStatus.innerHTML = '💭 Analyzing...';
                avatarStatus.style.backgroundColor = '#e0e7ff';
            }
            break;
        case 'smile':
            avatar.style.transform = 'scale(1)';
            avatar.style.boxShadow = '0 8px 25px rgba(99, 102, 241, 0.3)';
            if (avatarEmoji) avatarEmoji.innerHTML = '👩‍💼😊';
            if (avatarStatus) {
                avatarStatus.innerHTML = 'Ready to help!';
                avatarStatus.style.backgroundColor = '#e0e7ff';
            }
            setTimeout(() => {
                if (avatarEmoji && avatarStatus) {
                    avatarEmoji.innerHTML = '👩‍💼';
                    avatarStatus.innerHTML = 'Career Coach Ava';
                }
            }, 2000);
            break;
        default:
            avatar.style.transform = 'scale(1)';
            avatar.style.boxShadow = '0 8px 25px rgba(99, 102, 241, 0.3)';
            if (avatarEmoji) avatarEmoji.innerHTML = '👩‍💼';
            if (avatarStatus) {
                avatarStatus.innerHTML = 'Career Coach Ava';
                avatarStatus.style.backgroundColor = 'white';
            }
    }
}

// Speak with professional voice
function speakLikeCoach(text, onComplete = null) {
    if (!('speechSynthesis' in window)) {
        if (onComplete) onComplete();
        return;
    }
    
    window.speechSynthesis.cancel();
    
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'en-US';
    utterance.rate = 0.9;
    utterance.pitch = 1.1;
    utterance.volume = 1;
    
    // Try to get a professional female voice
    const voices = window.speechSynthesis.getVoices();
    const preferredVoices = ['Google UK English Female', 'Samantha', 'Microsoft Zira', 'Google US English Female'];
    for (const preferred of preferredVoices) {
        const voice = voices.find(v => v.name.includes(preferred));
        if (voice) {
            utterance.voice = voice;
            break;
        }
    }
    
    utterance.onend = () => {
        animateAvatar('default');
        if (onComplete) onComplete();
    };
    
    utterance.onerror = () => {
        animateAvatar('default');
        if (onComplete) onComplete();
    };
    
    animateAvatar('speaking');
    window.speechSynthesis.speak(utterance);
}

// Welcome user with professional tone
function professionalWelcome() {
    const userName = getCurrentUserName();
    const userNameDisplay = document.getElementById('userNameDisplay');
    if (userNameDisplay) userNameDisplay.innerText = userName;
    
    animateAvatar('thinking');
    
    setTimeout(() => {
        const welcomeText = `Hello ${userName}! I'm Ava, your professional career coach. I'm here to help you practice for your job interview. Let's work together to improve your interview skills. Are you ready to begin?`;
        speakLikeCoach(welcomeText);
    }, 800);
}

// Mock test welcome with professional tone
function professionalMockTestWelcome() {
    const userName = getCurrentUserName();
    
    animateAvatar('thinking');
    
    setTimeout(() => {
        const welcomeText = `Great to see you ${userName}! In this mock interview, I'll ask you 5 questions. You'll have 60 seconds for each question. You can type or speak your answers. Just be yourself and stay confident. Ready to start?`;
        speakLikeCoach(welcomeText, () => {
            setTimeout(() => {
                startProfessionalMockTest();
            }, 500);
        });
    }, 500);
}

function startProfessionalMockTest() {
    const jobRole = document.getElementById('jobRole')?.value || 'Software Developer';
    const experienceLevel = document.getElementById('experienceLevel')?.value || 'Mid';
    startInterviewQuestions(jobRole, experienceLevel);
}

// Speak question with professional tone
function speakProfessionalQuestion(question, questionNumber, totalQuestions) {
    animateAvatar('thinking');
    
    setTimeout(() => {
        const questionText = `Question ${questionNumber} of ${totalQuestions}. ${question}`;
        speakLikeCoach(questionText);
    }, 500);
}

// Show professional instructions
function showProfessionalInstructions() {
    const userName = getCurrentUserName();
    animateAvatar('thinking');
    
    const instructionsHTML = `
        <div id="professionalInstructions" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.6); display: flex; align-items: center; justify-content: center; z-index: 1000;">
            <div style="background: linear-gradient(135deg, #ffffff, #f3e8ff); border-radius: 20px; padding: 35px; max-width: 500px; width: 90%; text-align: center; box-shadow: 0 20px 40px rgba(0,0,0,0.2);">
                <div style="font-size: 70px;">👩‍💼🎯</div>
                <h2 style="color: #6366f1; margin: 15px 0;">Mock Interview with Ava</h2>
                <div style="text-align: left; margin: 20px 0; line-height: 1.8;">
                    <p>📌 <strong>Questions:</strong> 5 professional questions</p>
                    <p>⏱️ <strong>Time Limit:</strong> 60 seconds per question</p>
                    <p>🎤 <strong>Answer Method:</strong> Type or speak your answer</p>
                    <p>📹 <strong>Camera:</strong> Keep your face visible</p>
                    <p>💡 <strong>Pro Tip:</strong> Use STAR method (Situation, Task, Action, Result)</p>
                </div>
                <div style="display: flex; gap: 12px; justify-content: center;">
                    <button class="btn btn-primary" onclick="startProfessionalInterview()" style="background: #6366f1; padding: 10px 25px;">Start Interview →</button>
                    <button class="btn btn-outline" onclick="closeProfessionalInstructions()" style="border-color: #6366f1; color: #6366f1;">Cancel</button>
                </div>
            </div>
        </div>
    `;
    
    const existing = document.getElementById('professionalInstructions');
    if (existing) existing.remove();
    
    document.body.insertAdjacentHTML('beforeend', instructionsHTML);
    
    // Speak instructions
    const instructionText = `Hello ${userName}! I'm Ava, your career coach. In this mock interview, I'll ask you 5 questions with 60 seconds each. Remember to use the STAR method - Situation, Task, Action, Result. Click start when you're ready.`;
    speakLikeCoach(instructionText);
}

function closeProfessionalInstructions() {
    const instructionsDiv = document.getElementById('professionalInstructions');
    if (instructionsDiv) instructionsDiv.remove();
    window.speechSynthesis.cancel();
    animateAvatar('default');
}

function startProfessionalInterview() {
    closeProfessionalInstructions();
    professionalMockTestWelcome();
}

// Override displayCurrentQuestion to speak questions professionally
const originalDisplayQuestion = window.displayCurrentQuestion;
window.displayCurrentQuestion = function() {
    if (currentQuestionIndex < currentQuestions.length) {
        const question = currentQuestions[currentQuestionIndex];
        const qNumber = currentQuestionIndex + 1;
        speakProfessionalQuestion(question, qNumber, currentQuestions.length);
    }
    if (typeof originalDisplayQuestion === 'function') {
        originalDisplayQuestion();
    }
};

// Update startInterview to show professional instructions
const originalStart = window.startInterview;
window.startInterview = function() {
    if (!currentStream) {
        alert('⚠️ Please start camera first!');
        return;
    }
    showProfessionalInstructions();
};

// Update voice input to show listening animation
const originalVoiceInput = window.startVoiceInput;
window.startVoiceInput = function() {
    animateAvatar('listening');
    if (typeof originalVoiceInput === 'function') {
        originalVoiceInput();
    }
    setTimeout(() => {
        animateAvatar('default');
    }, 3000);
};

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    if (window.location.pathname.includes('interview.html')) {
        // Load voices
        window.speechSynthesis.getVoices();
        
        // Update user name display
        const userName = getCurrentUserName();
        const userNameDisplay = document.getElementById('userNameDisplay');
        if (userNameDisplay) userNameDisplay.innerText = userName;
        
        // Professional welcome after 1 second
        setTimeout(() => {
            professionalWelcome();
        }, 1000);
    }
});
 